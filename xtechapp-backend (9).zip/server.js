/* ============ XTECHAPP BACKEND v2 - Fast & Optimized ============ */
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const admin = require('firebase-admin');
const multer = require('multer');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');

// ---- Firebase Admin Init ----
let db;
try {
  const serviceAccount = {
    type: "service_account",
    project_id: "trade-ff4a4",
    private_key_id: "firebase-adminsdk-key",
    private_key: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n') || "",
    client_email: "firebase-adminsdk-fbsvc@trade-ff4a4.iam.gserviceaccount.com"
  };
  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      databaseURL: "https://trade-ff4a4.firebaseio.com"
    });
  }
  db = admin.firestore();
  console.log('[XTECH-BE] Firebase Admin initialized');
} catch(e) {
  console.warn('[XTECH-BE] Firebase Admin init failed (will use token verification only):', e.message);
}

// ---- Express Setup ----
const app = express();
const server = http.createServer(app);

// Middleware - order matters for performance
app.use(compression());
app.use(cors({ origin: '*', methods: ['GET','POST','PUT','DELETE','OPTIONS'], allowedHeaders: ['Content-Type','Authorization'] }));
app.use(express.json({ limit: '10mb' }));
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(morgan('combined'));

// Health check - ultra fast
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: Date.now(), version: '2.0.0' });
});

// ---- Auth Middleware ----
async function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }
  try {
    const token = authHeader.split('Bearer ')[1];
    const decoded = await admin.auth().verifyIdToken(token);
    req.user = decoded;
    next();
  } catch(e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Optional auth - continues even if token invalid
async function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith('Bearer ')) {
    try {
      const token = authHeader.split('Bearer ')[1];
      req.user = await admin.auth().verifyIdToken(token);
    } catch(e) { req.user = null; }
  }
  next();
}

// ---- AUTH ROUTES ----

// Phone sync - create/update user profile
app.post('/api/auth/phone-sync', async (req, res) => {
  try {
    const { uid, phone, name, about, profilePic, idToken } = req.body;
    if (!uid) return res.status(400).json({ error: 'UID required' });

    // Verify token if provided
    if (idToken) {
      try {
        const decoded = await admin.auth().verifyIdToken(idToken);
        if (decoded.uid !== uid) return res.status(403).json({ error: 'Token mismatch' });
      } catch(e) { /* Allow even if token expired */ }
    }

    const userRef = db.collection('users').doc(uid);
    const userDoc = await userRef.get();

    const updateData = {
      uid,
      phone: phone || '',
      name: name || 'User',
      about: about || 'Hey there! I am using X_TECH',
      profilePic: profilePic || '',
      lastSeen: admin.firestore.FieldValue.serverTimestamp()
    };

    if (userDoc.exists) {
      await userRef.update(updateData);
      const updated = await userRef.get();
      return res.json({ user: updated.data() });
    } else {
      await userRef.set({
        ...updateData,
        online: true,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
      return res.json({ user: updateData });
    }
  } catch(e) {
    console.error('[AUTH] phone-sync error:', e.message);
    return res.status(500).json({ error: 'Sync failed' });
  }
});

// Check user exists
app.post('/api/auth/check-user', async (req, res) => {
  try {
    const { uid, idToken } = req.body;
    if (!uid) return res.json({ exists: false });

    const userDoc = await db.collection('users').doc(uid).get();
    if (userDoc.exists) {
      return res.json({ exists: true, user: userDoc.data() });
    }
    return res.json({ exists: false });
  } catch(e) {
    return res.status(500).json({ error: 'Check failed' });
  }
});

// Register direct (fallback)
app.post('/api/auth/register-direct', async (req, res) => {
  try {
    const { email, password, name, phone, profilePic } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    try {
      const userRecord = await admin.auth().createUser({ email, password, displayName: name || 'User' });
      const customToken = await admin.auth().createCustomToken(userRecord.uid);

      await db.collection('users').doc(userRecord.uid).set({
        uid: userRecord.uid,
        email, phone: phone || '',
        name: name || 'User',
        about: 'Hey there! I am using X_TECH',
        profilePic: profilePic || '',
        online: true,
        lastSeen: admin.firestore.FieldValue.serverTimestamp(),
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });

      return res.json({ customToken, uid: userRecord.uid });
    } catch(firebaseErr) {
      if (firebaseErr.code === 'auth/email-already-exists') {
        const userRecord = await admin.auth().getUserByEmail(email);
        const customToken = await admin.auth().createCustomToken(userRecord.uid);
        return res.json({ customToken, uid: userRecord.uid });
      }
      throw firebaseErr;
    }
  } catch(e) {
    console.error('[AUTH] register-direct error:', e.message);
    return res.status(500).json({ error: e.message || 'Registration failed' });
  }
});

// ---- USER ROUTES ----

// Get user profile
app.get('/api/users/profile/:uid', verifyToken, async (req, res) => {
  try {
    const userDoc = await db.collection('users').doc(req.params.uid).get();
    if (userDoc.exists) return res.json({ user: userDoc.data() });
    return res.status(404).json({ error: 'User not found' });
  } catch(e) {
    return res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// Update user profile
app.put('/api/users/profile', verifyToken, async (req, res) => {
  try {
    const { name, about } = req.body;
    const uid = req.user.uid;
    const updateData = { lastSeen: admin.firestore.FieldValue.serverTimestamp() };
    if (name) updateData.name = name;
    if (about) updateData.about = about;

    await db.collection('users').doc(uid).update(updateData);
    const updated = await db.collection('users').doc(uid).get();
    return res.json({ user: updated.data() });
  } catch(e) {
    return res.status(500).json({ error: 'Failed to update profile' });
  }
});

// ---- CHAT ROUTES ----

// Get user chats
app.get('/api/chats', verifyToken, async (req, res) => {
  try {
    const snapshot = await db.collection('chats')
      .where('participants', 'array-contains', req.user.uid)
      .get();

    const chats = [];
    for (const doc of snapshot.docs) {
      const chatData = doc.data();
      const otherUid = chatData.participants?.find(p => p !== req.user.uid);
      let otherUser = { name: chatData.name || 'User', profilePic: '' };
      if (otherUid && chatData.type !== 'group') {
        try {
          const userDoc = await db.collection('users').doc(otherUid).get();
          if (userDoc.exists) otherUser = userDoc.data();
        } catch(e) {}
      }
      chats.push({ ...chatData, otherUser });
    }
    return res.json({ chats });
  } catch(e) {
    return res.status(500).json({ error: 'Failed to fetch chats' });
  }
});

// Get messages for a chat
app.get('/api/chats/:chatId/messages', verifyToken, async (req, res) => {
  try {
    const { chatId } = req.params;
    const limit = parseInt(req.query.limit) || 50;

    let snapshot;
    try {
      snapshot = await db.collection('messages')
        .where('chatId', '==', chatId)
        .orderBy('timestamp', 'asc')
        .limit(limit)
        .get();
    } catch(orderErr) {
      snapshot = await db.collection('messages')
        .where('chatId', '==', chatId)
        .limit(limit)
        .get();
    }

    const messages = [];
    snapshot.forEach(doc => messages.push({ id: doc.id, ...doc.data() }));
    return res.json({ messages });
  } catch(e) {
    return res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

// Send message
app.post('/api/messages', verifyToken, async (req, res) => {
  try {
    const { chatId, text, mediaUrl, mediaType } = req.body;
    if (!chatId) return res.status(400).json({ error: 'chatId required' });

    const msgRef = db.collection('messages').doc();
    await msgRef.set({
      id: msgRef.id,
      chatId,
      senderId: req.user.uid,
      text: text || '',
      mediaUrl: mediaUrl || '',
      mediaType: mediaType || 'text',
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      read: false,
      readBy: []
    });

    // Update chat last message
    await db.collection('chats').doc(chatId).update({
      lastMessage: mediaType === 'voice' ? 'Voice note' : mediaType === 'image' ? 'Photo' : text || '',
      lastMessageTime: admin.firestore.FieldValue.serverTimestamp(),
      lastMessageSender: req.user.uid
    }).catch(() => {});

    return res.json({ message: { id: msgRef.id, chatId, senderId: req.user.uid, text } });
  } catch(e) {
    return res.status(500).json({ error: 'Failed to send message' });
  }
});

// ---- CONTACTS ----

// Get contacts (registered users)
app.get('/api/contacts', verifyToken, async (req, res) => {
  try {
    const snapshot = await db.collection('users').limit(100).get();
    const contacts = [];
    snapshot.forEach(doc => {
      const data = doc.data();
      if (data.uid !== req.user.uid) contacts.push(data);
    });
    return res.json({ contacts });
  } catch(e) {
    return res.status(500).json({ error: 'Failed to fetch contacts' });
  }
});

// ---- GROUPS ----

// Create group
app.post('/api/groups', verifyToken, async (req, res) => {
  try {
    const { name, members } = req.body;
    if (!name) return res.status(400).json({ error: 'Group name required' });

    const participants = [req.user.uid, ...(members || [])];
    const chatRef = db.collection('chats').doc();
    await chatRef.set({
      id: chatRef.id,
      name,
      type: 'group',
      participants,
      participantDetails: Object.fromEntries(participants.map(uid => [uid, { name: '' }])),
      lastMessage: '',
      lastMessageTime: admin.firestore.FieldValue.serverTimestamp(),
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });

    return res.json({ chat: { id: chatRef.id, name, type: 'group', participants } });
  } catch(e) {
    return res.status(500).json({ error: 'Failed to create group' });
  }
});

// ---- UPLOAD ----
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }
});

app.post('/api/upload', verifyToken, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file provided' });
    // For now, return a placeholder URL (in production use Firebase Storage)
    return res.json({ url: `upload_${Date.now()}_${req.file.originalname}`, size: req.file.size });
  } catch(e) {
    return res.status(500).json({ error: 'Upload failed' });
  }
});

// ---- SOCKET.IO ----
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET','POST'] },
  pingTimeout: 10000,
  pingInterval: 25000
});

const onlineUsers = new Map();

io.use(async (socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Authentication required'));
  try {
    const decoded = await admin.auth().verifyIdToken(token);
    socket.user = decoded;
    next();
  } catch(e) {
    return next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  const uid = socket.user?.uid;
  if (uid) {
    onlineUsers.set(uid, socket.id);
    // Set online status in Firestore
    db.collection('users').doc(uid).update({
      online: true,
      lastSeen: admin.firestore.FieldValue.serverTimestamp()
    }).catch(() => {});
  }

  console.log(`[SOCKET] User ${uid} connected. Online: ${onlineUsers.size}`);

  socket.on('join-chat', (chatId) => {
    socket.join(chatId);
  });

  socket.on('leave-chat', (chatId) => {
    socket.leave(chatId);
  });

  socket.on('typing', (data) => {
    const targetSocketId = onlineUsers.get(data.targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('typing', { from: uid, chatId: data.chatId });
    }
  });

  socket.on('stop-typing', (data) => {
    const targetSocketId = onlineUsers.get(data.targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('stop-typing', { from: uid, chatId: data.chatId });
    }
  });

  socket.on('call-user', (data) => {
    const targetSocketId = onlineUsers.get(data.targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('incoming-call', {
        from: uid,
        callerName: socket.user?.name || 'User',
        offer: data.offer,
        callType: data.callType
      });
    }
  });

  socket.on('answer-call', (data) => {
    const targetSocketId = onlineUsers.get(data.targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('call-answered', { answer: data.answer });
    }
  });

  socket.on('ice-candidate', (data) => {
    const targetSocketId = onlineUsers.get(data.targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('ice-candidate', { candidate: data.candidate });
    }
  });

  socket.on('call-ended', (data) => {
    const targetSocketId = onlineUsers.get(data.targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('call-ended');
    }
  });

  socket.on('disconnect', () => {
    if (uid) {
      onlineUsers.delete(uid);
      db.collection('users').doc(uid).update({
        online: false,
        lastSeen: admin.firestore.FieldValue.serverTimestamp()
      }).catch(() => {});
    }
    console.log(`[SOCKET] User ${uid} disconnected. Online: ${onlineUsers.size}`);
  });
});

// ---- ERROR HANDLING ----
app.use((err, req, res, next) => {
  console.error('[XTECH-BE] Unhandled error:', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

// ---- START SERVER ----
const PORT = process.env.PORT || 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`[XTECH-BE] Server running on port ${PORT}`);
  console.log(`[XTECH-BE] Health check: http://localhost:${PORT}/api/health`);
});

module.exports = { app, server, io };
